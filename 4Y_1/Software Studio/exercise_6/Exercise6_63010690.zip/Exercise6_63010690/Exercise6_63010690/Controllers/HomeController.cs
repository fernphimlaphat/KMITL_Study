﻿using Exercise6_63010690.Models;
using Humanizer;
using Microsoft.AspNetCore.Mvc;
using NuGet.Packaging.Signing;
using System.Collections.Generic;
using System.Diagnostics;

namespace Exercise6_63010690.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult FormSubmit(string FirstName, string LastName, string Email, string Eiffel, string ANStext)
        {
            ViewBag.FirstName = FirstName;
            ViewBag.LastName = LastName;
            ViewBag.Email = Email;
            ViewBag.Eiffel = Eiffel;
            ViewBag.ANStext = ANStext;

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}